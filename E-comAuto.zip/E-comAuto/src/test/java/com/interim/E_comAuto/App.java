package com.interim.E_comAuto;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.NoSuchElementException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.devtools.v118.database.Database;
import org.openqa.selenium.devtools.v118.input.Input;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;

public class App {
	public static WebDriver driver;
	
	public void Driver(String browserChoice) {
		if (browserChoice.equalsIgnoreCase("chrome")) {
			driver = new ChromeDriver();
		} else if (browserChoice.equalsIgnoreCase("Edge")) {
			driver = new EdgeDriver();
		} else {
			System.out.println("Invalid browser choice(Please Select either Chrome or Edge)!");
			return;
		}
	}
	
	//To Maximize the Window of the flipkart screen
	// Open Flipkart website
	
	public void launchUrl() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.manage().window().maximize();
		driver.get("https://www.flipkart.com/");
	}
	
	//Handle popups if any
	
	public void popups() throws InterruptedException {
		Thread.sleep(3000);

		try {
	  WebElement closePopupButton = driver.findElement(By.cssSelector("div._10gS-S > img"));
		closePopupButton.click();
		//System.out.println("pop");

		} catch (NoSuchElementException e) {
		System.out.println("Pop up didn't appear");
		}
	}
	
	// Search for "mobiles under 15000" in search bar
	
	public void search() throws InterruptedException, IOException {
		WebElement searchBox = driver.findElement(By.className("Pke_EE"));
		
		/*
		FileInputStream file=new FileInputStream(System.getProperty("user.dir")+"\\database\\input.xlsx");
		XSSFWorkbook workbook=new XSSFWorkbook(file);
		XSSFSheet sheet=workbook.getSheet("Sheet1");
		String nam=sheet.getRow(0).getCell(0).toString();
		nam=nam+" ";
		*/
		
		String nam="mobiles under ";
	      searchBox.sendKeys(nam);
      
	   Thread.sleep(3000);
	}
	
	/*getting the auto complete search list and then clicking on 
	 the "mobiles under 15000" from auto suggest list*/
	
	public void mobile_under_15000() {
		driver.findElement(By.partialLinkText("15000")).click();
	}
	
	
	// In the Filters section, drag the price bar to 10000 as the max price
	//	Wait for the filtersDiv to be visible
	
	public void pricebar() throws InterruptedException {
		WebElement chos=driver.findElement(By.cssSelector("._3uDYxP>select[class='_2YxCDZ']"));	
		Select cho=new Select(chos);
		cho.selectByValue("10000");
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//div[@class='_2gmUFU _3V8rao' and starts-with(text(),'Operating System Version')]")).click();
		
		driver.findElement(By.xpath("//div[contains(text(),'Operating System Version Name')]/ancestor::section/div/div[@class=\"QvtND5 _2w_U27\"]")).click();
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//div[contains(text(),'Pie')]")).click();
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//div[text()='Newest First']")).click();
		Thread.sleep(5000);
	}
	
	// Check if the first mobile price is less than 30000
	
	public void name_price() {
		//list of name and price 
		List <WebElement> name=driver.findElements(By.className("_4rR01T"));
		List <WebElement> price=driver.findElements(By.className("_30jeq3"));
		
		//display first five  name and price of mobiles 

		for(int i=0;i<5;i++) {
			System.out.println(name.get(i).getText());
			System.out.println(price.get(i).getText());
		}
		
		String c=price.get(0).getText();
		// i want to remove ₹ so i take substring 
		String sub=c.substring(1);
		String c1=name.get(0).getText();
		//System.out.println(c1+""+"name");
		String firstmobileprice=sub;
		//i want to remove , so i used arraylist
	    String[] st=firstmobileprice.split(",",0);
	    String d="";
	    for(int i=0;i<st.length;i++){
	        d+=st[i];
	    }
	    int number=Integer.parseInt(d);
	    
		// if the first mobile price is less than 30000
	    if(number <30000){
            System.out.println("Less than 30000");
        }else {
            System.out.println("Not less than 30000");
        }
        driver.quit();
	}
	
	
}