package com.interim.E_comAuto;

import java.io.IOException;
//import java.time.Duration;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;

import org.openqa.selenium.StaleElementReferenceException;



public class Flipkart {
	
	public static void main(String[] args) throws InterruptedException,StaleElementReferenceException, IOException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter browser choice (Chromes/Edge): ");
		String browserChoice = sc.nextLine();
		
		App app=new App();
		app.Driver(browserChoice);
		app.launchUrl();
		app.popups();
	    app.search();
	    app.mobile_under_15000();
	    app.pricebar();
	    app.name_price();	 
	    
	}
}
