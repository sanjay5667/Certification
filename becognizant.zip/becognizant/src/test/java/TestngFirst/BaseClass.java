package TestngFirst;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import TestngApps.appswindow;
import TestngNews.news;
import io.github.bonigarcia.wdm.WebDriverManager;

import java.io.IOException;
import java.time.Duration;
import java.util.List;


public class BaseClass {
   WebDriver driver;
   
		   @BeforeClass
		   void setup() throws InterruptedException{
		       //WEB DRIVER
			   WebDriverManager.chromedriver().setup();
			   driver = new ChromeDriver();
			   driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
			   // Test Case 01 : Navigate to the be cognizant portal.
			   driver.get("https://cognizantonline.sharepoint.com/sites/Be.Cognizant/SitePages/Home.aspx");
			   driver.manage().window().maximize();
		   }
   
//**********************************************************************************************************************   
		   
// Test Case 02 : Capture the user information at the top right corner, Should get all the information and you should verify the information.
		   @Test(priority = 1)
		   public void captureAndVerifyUserInfo() throws InterruptedException {
			   Thread.sleep(20000);
			   driver.findElement(By.xpath("//div[@class='_8ZYZKvxC8bvw1xgQGSkvvA==']")).click();
			   Thread.sleep(10000);
		   }
//		   @Test(priority = 2)
//		   void testUsername() {
//			   System.out.println("======================================================");
//			   UserVerification pageObjectModel = new UserVerification(driver);
//			   pageObjectModel.setUserName();
//		   }
//		   @Test(priority = 3)
//		   void testUserEmail() {
//			   UserVerification pageObjectModel = new UserVerification(driver);
//			   pageObjectModel.setUserEmail();
//
//		   }
		   
//		   @Test(priority = 4)
//		   void newsvalidate() throws InterruptedException {
//			   news nw = new news(driver);
//			   nw.featurednews();
//		   }
//		   
		   @Test(priority = 5)
		   void apps() throws InterruptedException, IOException {
			   appswindow ap = new appswindow(driver);
			   ap.apps();
		   }
	       

//   @AfterClass
//   public void tearDown() {
//       // Close the browser
//       driver.quit();
//   }
}