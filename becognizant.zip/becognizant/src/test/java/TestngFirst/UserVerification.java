package TestngFirst;
 
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
 
public class UserVerification extends BaseClass {
	
	WebDriver driver;
	
	//Constructor
	UserVerification(WebDriver driver)
	{
		this.driver=driver;
	}
	

	//Locators
	@FindBy(xpath="//div[@class='_8ZYZKvxC8bvw1xgQGSkvvA==']") WebElement UserProfile; //By Using "@FindBy" method.
	By user_name = By.xpath("//*[@id='mectrl_currentAccount_primary']");
    @CacheLookup
    private WebElement userName;
    By user_email = By.xpath("//div[@class='mectrl_accountDetails']//div[@class='mectrl_truncate']");
    @CacheLookup
    private WebElement useremail;
	
	
	//Action
	void ClickingProfile() throws InterruptedException {
		UserProfile.click();
	}
	
	public void setUserName() {
		String username = driver.findElement(user_name).getText();
		System.out.println("Extrected name from webpage: "+username);
		String expectedinfoname = "Utkarsh, Abhinav (Cognizant)";
		Assert.assertEquals(username, expectedinfoname, "Not Match");
	}
	
	public void setUserEmail() {
		String useremail = driver.findElement(user_email).getText();
		System.out.println("Extrected email from webpage: "+useremail);
		String expectedinfo = "2308519@cognizant.com";
		Assert.assertEquals(useremail, expectedinfo, "Not Match");
		System.out.println("Correct User : Abhinav Utkarsh");
	}
	
	
	
}