package TestngNews;
 
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import TestngFirst.BaseClass;
 
public class news extends BaseClass {
	
	WebDriver driver;
	
	//Constructor
	public news(WebDriver driver)
	{
		this.driver=driver;
	}
	

	//Locators
	@FindBy(xpath="//div[@class='_8ZYZKvxC8bvw1xgQGSkvvA==']") WebElement UserProfile; //By Using "@FindBy" method.
	By user_name = By.xpath("//*[@id='mectrl_currentAccount_primary']");
    @CacheLookup
    private WebElement userName;

	
	
	//Action
	public void featurednews() throws InterruptedException{
		List<WebElement> lists = driver.findElements(By.xpath("//div[@class='e_a_37591358 q_a_37591358']"));
		int numberOfNews = lists.size();
		System.out.println("Number of news articles: " + numberOfNews);
		   System.out.println("======================================================");
		   Thread.sleep(2000);
		   for(int i=0; i<numberOfNews; i++) {
			   WebElement list = driver.findElements(By.xpath("//div[@class='e_a_37591358 q_a_37591358']")).get(i);
			   Thread.sleep(10000);
			   list.click();
			   Thread.sleep(10000);
			   WebElement header = driver.findElement(By.xpath("//div[@id='title_text']"));
			   System.out.println("Header Value: "+header.getText());
			   
			   driver.navigate().back(); 
			   Thread.sleep(10000);
		   }
		   System.out.println("===================================================");
		   System.out.println("News Articles Verified");
		   System.out.println("===================================================");
	}
	
	
	
	
	
}