package TestngApps;
 
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import TestngFirst.BaseClass;
 
public class appswindow extends BaseClass {
	
	WebDriver driver;
	
	//Constructor
	public appswindow(WebDriver driver)
	{
		this.driver=driver;
	}
	

	//Locators
	@FindBy(xpath="//div[@class='_8ZYZKvxC8bvw1xgQGSkvvA==']") WebElement UserProfile; //By Using "@FindBy" method.
	By user_name = By.xpath("//*[@id='mectrl_currentAccount_primary']");
    @CacheLookup
    private WebElement userName;

	
	
	//Action
	public void apps() throws InterruptedException, IOException{
		driver.findElement(By.xpath("//div[normalize-space()='All Apps & Tools']//div[@id='QuicklinksItemTitle']")).click();
		   Thread.sleep(10000);

		   System.out.println("    ");
		   System.out.println("***********A-E************");
		   WebElement specificDiv = driver.findElement(By.xpath("//div[@id='fa45f946-463e-428f-a84b-0bbbde09c3ba']"));
	       WebElement unorderedList = specificDiv.findElement(By.tagName("ul"));
	       List<WebElement> listItems = unorderedList.findElements(By.tagName("li"));
	       for (WebElement listItem : listItems) {
	           WebElement anchorElement = listItem.findElement(By.tagName("a"));
	           String linkName = anchorElement.getText();
	           System.out.println(linkName);
	       } 
	     //*********************
	       FileOutputStream file=new FileOutputStream("C:\\Eclipse work space\\becognizant\\ExcelFiles\\Apps1.xlsx");
			 XSSFWorkbook workbook=new XSSFWorkbook();
			 XSSFSheet sheet=workbook.createSheet();
		    for(int i=0;i<listItems.size();i++) {
		    	 String ae = listItems.get(i).getText();
		    	 XSSFRow currentrow = sheet.createRow(i);
		    	   XSSFCell cell = currentrow.createCell(0);
		    	   cell.setCellValue(ae);
		    	  
		     }
		    workbook.write(file);
			 workbook.close();
			 file.close();
	       //*********************
	       System.out.println("    ");
	       System.out.println("***********G-O************");
	       WebElement specificDiv2 = driver.findElement(By.xpath("//div[@id='f8ff0d88-59b2-40c6-b2d7-f5c4f21c580b']"));
	       WebElement unorderedList2 = specificDiv2.findElement(By.tagName("ul"));
	       List<WebElement> listItems2 = unorderedList2.findElements(By.tagName("li"));
	       for (WebElement listItem2 : listItems2) {
	           WebElement anchorElement2 = listItem2.findElement(By.tagName("a"));
	           String linkName2 = anchorElement2.getText();
	           System.out.println(linkName2);
	       } 
	     //*********************
			 FileOutputStream file1=new FileOutputStream("C:\\Eclipse work space\\becognizant\\ExcelFiles\\Apps2.xlsx");
			 XSSFWorkbook workbook1=new XSSFWorkbook();
			 XSSFSheet sheet1=workbook1.createSheet();
		    for(int i=0;i<listItems2.size();i++) {
		    	 String ae = listItems2.get(i).getText();
		    	 XSSFRow currentrow = sheet1.createRow(i);
		    	   XSSFCell cell = currentrow.createCell(0);
		    	   cell.setCellValue(ae);
		    	  
		     }
		    workbook1.write(file1);
			 workbook1.close();
			 file1.close();
		  //*********************
	       System.out.println("    ");
	       System.out.println("***********P-Z************");
	       WebElement specificDiv3 = driver.findElement(By.xpath("//div[@id='68fa06aa-8076-4795-ab31-3c19dcc90d27']"));
	       WebElement unorderedList3 = specificDiv3.findElement(By.tagName("ul"));
	       List<WebElement> listItems3 = unorderedList3.findElements(By.tagName("li"));
	       for (WebElement listItem3 : listItems3) {
	           WebElement anchorElement3 = listItem3.findElement(By.tagName("a"));
	           String linkName3 = anchorElement3.getText();
	           System.out.println(linkName3);
	           Thread.sleep(5000);
	       } 
	     //*******************************
			 FileOutputStream file2=new FileOutputStream("C:\\Eclipse work space\\becognizant\\ExcelFiles\\Apps3.xlsx");
			 XSSFWorkbook workbook2=new XSSFWorkbook();
			 XSSFSheet sheet2=workbook2.createSheet();
		    for(int i=0;i<listItems3.size();i++) {
		    	 String ae = listItems3.get(i).getText();
		    	 XSSFRow currentrow = sheet2.createRow(i);
		    	   XSSFCell cell = currentrow.createCell(0);
		    	   cell.setCellValue(ae);
		    	  
		     }
		    workbook2.write(file2);
			 workbook2.close();
			 file2.close();
			       //*********************
	}
	
	
	
	
	
}